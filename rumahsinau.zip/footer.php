 <footer class="page-footer teal">
    <div class="container">
      <div class="row">
        <div class="col l4 s12">
          <h5 class="white-text">Butuh Bantuan ?</h5>
          <p class="grey-text text-lighten-4">Kirim email ke kami</p>
          <p class="grey-text text-lighten-4">admin@rumahsinau.com</p>
        </div>
        <div class="col l4 s12">
          <h5 class="white-text">Informasi Lain</h5>
          <ul>
            <li><a class="white-text" href="faq.php">FAQ</a></li>
            <li><a class="white-text" href="blog.rumahsinau.org">Blog</a></li>
          </ul>
        </div>
        <div class="col l4 s12">
          <h5 class="white-text">Ikuti Kami</h5>
          <div class="fb-page" data-href="https://www.facebook.com/rumahsinau" data-tabs="" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/rumahsinau" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/rumahsinau">Rumah Sinau</a></blockquote></div>
        </div>
      </div>
    </div>
    <div class="footer-copyright">
      <div class="container">
      Made by <a class="brown-text text-lighten-3" href="http://materializecss.com">Materialize</a>
      </div>
    </div>
  </footer>